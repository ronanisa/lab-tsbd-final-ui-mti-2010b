<?php
	@$username = $_POST['username'];
	@$nav = $_POST['nav'];
	@$left = $_POST['left'];
	@$str = $_POST['str'];
	
	if(!isset($username)){
		include "home.php";	
						}				
	if($username=="ptkai"){
	//	include "pemilik.php";	
	header("location:pemilik.php");
						}
	if($username=="pegawai"){
//		include "pegawai.php";
	header("location:pegawai.php");
	}
	if($username=="admin"){
//		include "admin.php";
	header("location:admin.php");
	}


?>


