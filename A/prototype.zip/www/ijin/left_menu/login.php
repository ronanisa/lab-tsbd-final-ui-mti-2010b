
			<form id="loginForm" action="index.php" method="post">
				<p>ENTER USER NAME : 
					<input type="text" name="username">
				</p>
				<p> ENTER PASSWORD :
					<input type="password" name="password">
					<input type="button" value="Check In" name="Submit" onclick="login();" >
				</p>
			<input  TYPE="hidden" VALUE="logged" NAME="nav"> 

			</form>
