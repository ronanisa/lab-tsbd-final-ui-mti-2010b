<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<link rel="stylesheet" href="screen.css" type="text/css" media="screen" />	
	<script type="text/javascript" src="general.js"></script>	
	<title>Sertifikasi Sarana Perkeretaapian</title>
	<style type="text/css">
	@import url(style.css);
	</style>
</head>
<body>

<div id="wrapper">
	<div id="topbar">
    	PROTOTYPE
    </div>
    <div id="header">
    	<div id="logo">
        	Kementerian <strong>Perhubungan</strong> RI
            <span>Sertifikasi Sarana Perkeretaapian</span>
        </div>
		<ul id="navigation">
			<li><a href="index.php" class="selected">Log Out</a></li>
			<li><a href="#three">Help</a></li>
		</ul>
    </div> 
    <div id="body">
    	<div id="leftmenu">
    	<h4>Status:</h4><br>
		<h4>Staff KemHub</h4>
        <div class="seperator"></div>
<p>		<h1>Dokumen Peraturan</h1></p>
			<h2><a href="\doc\km._no._40_tahun_2010.pdf">KM No.40 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._41_tahun_2010.pdf">KM No.41 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._42_tahun_2010.pdf">KM No.42 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._43_tahun_2010.pdf">KM No.43 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._44_tahun_2010.pdf">KM No.44 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._45_tahun_2010.pdf">KM No.45 tahun 2010</a></h2>	
		<div class="seperator"></div>

     <img src="\images\direktori_perhubungan.jpg" name="Image">   <br> 

  		</div>
		<div id="content">
        <div class="form">
        	<h3>Informasi Umum</h3>
            <br /><br />
            <table>
            <tr>
			<td>
				<label for="form_name">Pemilik</label>
			</td>
			<td>
			    	<select>
			    	<option value="">Pilih Pemilik</option>
					    <option value="">PT KAI</option>
					    <option value="">Pertamina</option>
					</select>
			
			</td>
			</tr>
			<tr>
				<td>
            		<label for="form_name">Jenis Sarana</label>			
				</td>
				<td>  
			    	<select>
			    	<option value="">Pilih Jenis Sarana</option>
					    <option value="">Lokomotif</option>
					    <option value="">KRL</option>
					    <option value="">KRD</option>
					    <option value="">Kereta</option>
					    <option value="">Gerbong</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
        		    <label for="form_email">No. Sarana</label>
				</td>
				<td>
            		<input type="text" name="no_sarana" id="form_email" value="xx.xxxx.xxxx" />      	
				</td>	
			</tr>
			<tr>
				<td>
		            <label for="form_comments">Jenis Pengujian</label> 					
				</td>
				<td>
					<select>
						<option>Uji Pertama</option>
						<option>Uji Berkala</option>
					</select>	
				</td>
			</tr>
			<tr>
				<td>
					<label>Tanggal Pengujian</label>
				</td>
				<td>
					<select>
						<?php 						
						for($i=1;$i<=31;$i++){
							echo '<option>'.$i.'</option>';
						}
						?>
					</select>	
		
				<select>
					<option>Januari</option>
					<option>Februari</option>
					<option>Maret</option>
					<option>April</option>
					<option>Mei</option>
					<option>Juni</option>
					<option>Juli</option>
					<option>Agustus</option>
					<option>September</option>
					<option>Oktober</option>
					<option>November</option>
					<option>Desember</option>
				
				</select>
				<select>
				<?php 						
						for($i=2008;$i<=2030;$i++){
							echo '<option>'.$i.'</option>';
						}
				
				?>
				
				</select>
			
			</tr>
			<tr>
				<td>
        		    <label for="form_email">Nama Pemilik</label>
				</td>
				<td>
            		<input type="text" name="no_sarana" id="form_email" value="" />      	
				</td>	
			</tr>
			<tr>
				<td>
        		    <label for="form_email">Alamat Pemilik</label>
				</td>
				<td>
            		<input type="text" name="no_sarana" id="form_email" value="" />      	
				</td>	
			</tr>
			<tr>
				<td>
        		    <label for="form_email">Masa Berlaku</label>
				</td>
				<td>
            		<input type="text" name="no_sarana" id="form_email" value="xx.xxxx.xxxx" />      	
				</td>	
			</tr>

			</table>
				</div>
		<table>
		<tr>
		<td>
		<h3><input type="Submit" class="button" value="Simpan" name="button" ></h3>
		</td>		
		<td>
		<a href="pegawai.php"><h3><input type="Button" class="button" value="Back" name="button" ></h3></a>
		</td>
		</tr>
		
		</table>
	
		</div>
        <div class="clear"></div>
        <div id="footer">
            Puguh Arry Wibowo | 
           	Tasha Imansyah | 
            Anton Wijaya | 
            Ari Lundi Ayu | 
            Dhaniel Juliandra Siregar
            
  		<p>	Copyright &copy; 2010 <a href="http://www.facebook.com/andrasiregar">72gar&trade;</a>
	    </div>
    </div>
</div>

</body>
</html>

