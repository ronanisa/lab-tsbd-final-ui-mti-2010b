<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<link rel="stylesheet" href="screen.css" type="text/css" media="screen" />	
	<script type="text/javascript" src="general.js"></script>	
	<title>Sertifikasi Sarana Perkeretaapian</title>
	<style type="text/css">
	@import url(style.css);
	</style>
</head>
<body>

<div id="wrapper">
	<div id="topbar">
    	PROTOTYPE
    </div>
    <div id="header">
    	<div id="logo">
        	Kementerian <strong>Perhubungan</strong> RI
            <span>Sertifikasi Sarana Perkeretaapian</span>
        </div>
		<ul id="navigation">
			<li><a href="?m=home.php" class="selected">Log Out</a></li>
			<li><a href="#three">Help</a></li>
		</ul>
    </div> 
    <div id="body">
    	<div id="leftmenu">
	Welcome, Pegawai
			<div id="quotestart"></div>

            <p>			
			<a href="www.dephub.go.id">Dokumen Peraturan</a><br>
			<a href="www.dephub.go.id">Dokumen Peraturan</a><br>
			<a href="www.dephub.go.id">Dokumen Peraturan</a><br>
			
			
			This is an example of a customer testimonial. Place good reviews or something else here. It will look good :)<br /><br /></p>
				<div class="right">
					Gill Bates<br />
					CEO &amp; Founder<br />
					randomsite.com
				</div><br clear="all" />
			<div id="quoteend"></div><br clear="all" />
        
        <div class="seperator"></div>
        
        <div class="form">
        	<h3>Quick contact</h3>
            This form is not coded, you will need to most likely configure a serverside script to make this emailer work! 
            <br /><br />
            <label for="form_name">Name</label>
            <input type="text" name="name" id="form_name" value="John Smith" /> 
            
            <label for="form_email">Contact Method</label>
            <input type="text" name="email" id="form_email" value="hello@aim.com" />      
            
            <label for="form_comments">Message</label> 
            <textarea id="form_comments" rows="4" cols="22">I would like to request your services</textarea>
            
            <button value="Submit" class="send_button" onclick="this.form.submit();">SUBMIT</button>
            <br clear="all" />
        </div>
  		</div>
		
		<div id="content">
<img src="\images\sertifikat2.png" name="Image"><br>
		<a href="input_sertifikat_hasil_uji_sarana3.php"><h3><input type="Button" class="button" value="Next" name="Submit" ></h3></a>
		</div>
        
        <div class="clear"></div>
        <div id="footer">
            <span><a href="#">Home</a></span> | 
            <a href="#">Services</a> | 
            <a href="#">Portfolio</a> | 
            <a href="#">Articles</a> | 
            <a href="#">Contact</a>
            
            <!-- START OF ZYMIC.COM COPYRIGHT, DO NOT REMOVE OR EDIT ANYTHING BELOW WITHOUT PAYING LICENSE FEE (ELSE FACE LEGAL ACTION) -->
		<p>	Copyright &copy; 2007 <a href="http://www.zymic.com/free-templates/">Free Templates</a> by <a href="http://www.zymic.com">Zymic</a> - <a href="http://www.zymic.com/free-web-hosting/">Free Web Hosting</a> - Best Viewed in <a href="http://www.mozillafirefox.us">Mozilla Firefox</a></p>
	    <!-- END ZYMIC.COM COPYRIGHT -->
	    </div>
    </div>
</div>

</body>
</html>
