
 <img src="\images\kereta2.png" name="Image">
        <h3>
        <p>Menurut Undang-Undang No. 23 Tahun 2007 tentang Perkerataapian, untuk memenuhi persyaratan teknis dan menjamin kelaikan operasi sarana perkerataapian wajib dilakukan pengujian dan pemeriksaan. 
		<br><br> Pengujian sarana perkerataapian terdiri atas uji pertama dan uji berkala. Uji pertama wajib dilakukan terhadap setiap sarana perkeretaapian yang telah mengalami perubahan spesifkasi teknis. Uji berkala wajib dilakukan untuk sarana perkeretaapian yang telah dioperasikan.
		</h3>
        <br /><br />
        <a href="http://www.zymic.com/template-customization/" >http://www.zymic.com/template-customization/</a>
        </p>

