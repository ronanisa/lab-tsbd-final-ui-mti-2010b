			<li><a href="?m=home.php" class="selected">Informasi Umum</a></li>
			<li><a href="?m=service.php">Laporan            </a></li>
			<li><a href="#three">Help</a></li>