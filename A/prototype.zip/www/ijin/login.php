<html>

<head>

<script>

function f()

{

if(document.getElementById('uid').value.length==0)

alert("UserId can't be blank");

else if(document.getElementById('pwd').value.length==0)

alert("Password can't be blank");

else 

{

alert("successfully logged in");

window.open("Welcome.html");

}

}
</script>

</head>

<body>

UserId : <input type="text" id="uid">
<br/>

Passowrd: <input type="text" id="pwd">
<br /><br/>

<input type ="button" onclick="f()" value ="LogIn">

</body>

</html>