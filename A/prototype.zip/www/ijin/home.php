<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<link rel="stylesheet" href="screen.css" type="text/css" media="screen" />	
	<script type="text/javascript" src="general.js"></script>	
	<title>Sertifikasi Sarana Perkeretaapian</title>
	<style type="text/css">
	@import url(style.css);
	</style>
</head>

<body>
<div id="wrapper">
	<div id="topbar">
    	PROTOTYPE
    </div>
    <div id="header">
    	<div id="logo">
    	       <strong>Sertifikasi Sarana Perkeretaapian</strong>
            <span>Kementerian Perhubungan RI</span>
<!--
        	Kementerian <strong>Perhubungan</strong> RI
            <span>Sertifikasi Sarana Perkeretaapian</span>
-->
        </div>
		<ul id="navigation">
			<li><a href="?m=home.php" class="selected">Informasi Umum</a></li>
			<li><a href="?m=service.php">Laporan</a></li>
			<li><a href="#three">Help</a></li>
		</ul>
    </div>
 
    <div id="body">
    	<div id="leftmenu">
			<form id="loginForm" action="index.php" method="post">
				<p>ENTER USER NAME : 
					<input type="text" name="username">
				</p>
				<p> ENTER PASSWORD :
					<input type="password" name="password">
					<input type="button" value="Sign In" name="Submit" onclick="login();" >
				</p>
			</form>				
<br>
        <div class="seperator"></div>
<p>		<h1>Dokumen Peraturan</h1></p>
			<h2><a href="\doc\km._no._40_tahun_2010.pdf">KM No.40 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._41_tahun_2010.pdf">KM No.41 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._42_tahun_2010.pdf">KM No.42 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._43_tahun_2010.pdf">KM No.43 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._44_tahun_2010.pdf">KM No.44 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._45_tahun_2010.pdf">KM No.45 tahun 2010</a></h2>					
        <div class="seperator"></div>
     <img src="\images\direktori_perhubungan.jpg" name="Image">   <br> 
  		</div>
		
		<div id="content">
<img src="\images\kereta2.jpg" name="Image">

        <h3>
        <p>Menurut Undang-Undang No. 23 Tahun 2007 tentang Perkeretaapian, untuk memenuhi persyaratan teknis dan menjamin kelaikan operasi sarana perkeretaapian wajib dilakukan pengujian dan pemeriksaan. 
		<br><br> Pengujian sarana perkeretaapian terdiri atas uji pertama dan uji berkala. Uji pertama wajib dilakukan terhadap setiap sarana perkeretaapian yang telah mengalami perubahan spesifkasi teknis. Uji berkala wajib dilakukan untuk sarana perkeretaapian yang telah dioperasikan.
		</h3>
        </p>
		</div>
        
        <div class="clear"></div>
        <div id="footer">
            Puguh Arry Wibowo | 
           	Tasha Imansyah | 
            Anton Wijaya | 
            Ari Lundi Ayu | 
            Dhaniel Juliandra Siregar
            
  		<p>	Copyright &copy; 2010 <a href="http://www.facebook.com/andrasiregar">72gar&trade;</a>
	    </div>
    </div>
</div>

</body>
</html>
