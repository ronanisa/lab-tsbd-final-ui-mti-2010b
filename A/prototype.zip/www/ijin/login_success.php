<?php

if ( !isset( $_SESSION['mysession'])) {
Header("Location:index.php");
}
?>
