<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Content Switcher with jQuery as an Enhancement</title>
	<link rel="stylesheet" href="screen.css" type="text/css" media="screen" />
	<script type="text/javascript" src="general.js"></script>
</head>

<body style="width: 98%;">

	<div style="width: 625px; margin: 0 auto 0 auto;">
	<h1>Adding jQuery to Enhance the Content Switcher</h1>

		<div id="content-slider">
			<ul id="content-slider-inside">
				<li id="one">1</li>
				<li id="two">2</li>
				<li id="three">3</li>
				<li id="four">4</li>
				<li id="five">5</li>
			</ul>
		</div>
		
		<ul id="navigation">
			<li><a href="#one" class="selected">1</a></li>
			<li><a href="#two">2</a></li>
			<li><a href="#three">3</a></li>
			<li><a href="#four">4</a></li>
			<li><a href="#five">5</a></li>
		</ul>

	<p>This page uses JavaScript/jQuery to enhance the already-functioning content slider/switcher.</p>

	<p><a href="http://www.impressivewebs.com/demo-files/content-switcher/content-switcher.html">View the page without JavaScript</a></p>

	<p><a href="http://www.impressivewebs.com/javascript-content-switcher-without-javascript/">&lt; Go back to the tutorial</a></p>

	</div>

</body>
</html>
