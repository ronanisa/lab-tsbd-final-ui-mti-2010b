<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<link rel="stylesheet" href="screen.css" type="text/css" media="screen" />	
	<script type="text/javascript" src="general.js"></script>	
	<title>Sertifikasi Sarana Perkeretaapian</title>
	<style type="text/css">
	@import url(style.css);
	</style>
</head>
<body>

<div id="wrapper">
	<div id="topbar">
    	PROTOTYPE
    </div>
    <div id="header">
    	<div id="logo">
    	       <strong>Sertifikasi Sarana Perkeretaapian</strong>
            <span>Kementerian Perhubungan RI</span>
<!--
        	Kementerian <strong>Perhubungan</strong> RI
            <span>Sertifikasi Sarana Perkeretaapian</span>
-->
        </div>
		<ul id="navigation">
			<li><a href="index.php" class="selected">Log Out</a></li>
			<li><a href="#three">Help</a></li>
		</ul>
    </div> 
    <div id="body">
    	<div id="leftmenu">
    	<h4>Status:</h4><br>
		<h4>PT. Kereta Api Indonesia</h4>
        <div class="seperator"></div>
<p>		<h1>Dokumen Peraturan</h1></p>
			<h2><a href="\doc\km._no._40_tahun_2010.pdf">KM No.40 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._41_tahun_2010.pdf">KM No.41 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._42_tahun_2010.pdf">KM No.42 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._43_tahun_2010.pdf">KM No.43 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._44_tahun_2010.pdf">KM No.44 tahun 2010</a></h2>
			<h2><a href="\doc\km._no._45_tahun_2010.pdf">KM No.45 tahun 2010</a></h2>	
		<div class="seperator"></div>

     <img src="\images\direktori_perhubungan.jpg" name="Image">   <br> 

  		</div>
		
		<div id="content">
<table>
<tr><td>
			<a href="permintaan_sertifikasi_sarana.php"><h3><input type="Button" class="button" value="Permintaan Sertifikasi Sarana" name="button" ></h3></a><br>
</td></tr>
<!--
<tr><td>
			<a href="sertifikasi_hasil_uji_sarana.php"><h3><input type="Button" class="button" value="Sertifikasi Hasil Uji Sarana" name="button" ></h3></a><br>

</td></tr>
-->
<tr><td>
			<a href="laporan_hasil_pengujian.php"><h3><input type="Button" class="button" value="Laporan Hasil Pengujian" name="button" ></h3></a><br>

</td></tr>
</table>


		</div>
        
        <div class="clear"></div>
        <div id="footer">
            Puguh Arry Wibowo | 
           	Tasha Imansyah | 
            Anton Wijaya | 
            Ari Lundi Ayu | 
            Dhaniel Juliandra Siregar
            
  		<p>	Copyright &copy; 2010 <a href="http://www.facebook.com/andrasiregar">72gar&trade;</a>
	    </div>
    </div>
</div>

</body>
</html>
